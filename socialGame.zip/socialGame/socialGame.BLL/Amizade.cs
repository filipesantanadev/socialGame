﻿/*using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace socialGame.BLL
{
    public class Amizade
    {
        public int UsuarioIdA { get; set; }
        public int UsuarioIdB { get; set; }
        public User UsuarioA { get; set; }
        public User UsuarioB { get; set; }
    }
}*/